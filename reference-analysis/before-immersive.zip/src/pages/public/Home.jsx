import { useEffect, useState } from 'react'
import SEO from '../../components/ui/SEO'
import Hero from '../../components/home/Hero'
import SkillsMarquee from '../../components/home/SkillsMarquee'
import FeaturedProjects from '../../components/home/FeaturedProjects'
import ExperienceSection from '../../components/home/ExperienceSection'
import HackathonsSection from '../../components/home/HackathonsSection'
import ExpertiseSection from '../../components/home/ExpertiseSection'
import CTASection from '../../components/home/CTASection'
import { dataService } from '../../lib/dataService'

export default function Home() {
    const profile = dataService.getProfile()
    const events = dataService.getEvents()
    const [skills, setSkills] = useState([])
    const [projects, setProjects] = useState([])
    const [experiences, setExperiences] = useState([])

    useEffect(() => {
        dataService.getSkills().then(setSkills).catch(() => {})
        dataService.getProjects().then(setProjects).catch(() => {})
        dataService.getExperiences().then(setExperiences).catch(() => {})
    }, [])

    return (
        <>
            <SEO
                title={null}
                description={`Portfolio of ${profile.name} — ${(profile.roles || []).join(' & ')}. ${profile.shortBio}`}
                url="/"
            />
            <div className="space-y-8">
                <div className="pt-32 pb-8 max-w-7xl mx-auto px-4 sm:px-6">
                    <Hero profile={profile} />
                </div>
                <SkillsMarquee skills={skills} />
                <FeaturedProjects projects={projects} />
                <ExpertiseSection />
                <ExperienceSection experience={experiences} />
                <HackathonsSection events={events} />
                <CTASection profile={profile} />
            </div>
        </>
    )
}
