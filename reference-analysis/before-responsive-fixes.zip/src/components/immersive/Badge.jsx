import { useEffect, useRef, useState } from 'react'
import { Code2, Layers, Cpu, Globe, ArrowUpRight } from 'lucide-react'
import { useReducedMotion } from '../../hooks/useReducedMotion'

export default function Badge({ profile, ready }) {
 const host = useRef(null), card = useRef(null), rope = useRef(null), rig = useRef({ x: 0, y: -440, vx: 0, vy: 0, angle: 0, flip: 0, target: 0, dragging: false, tx: 0, ty: 0, tilt: 0, moved: false })
 const [back, setBack] = useState(false)
 const reduced = useReducedMotion()
 const flip = () => { rig.current.target += 180; setBack(Math.round(rig.current.target / 180) % 2 === 1) }
 useEffect(() => {
  if (!ready) return
  const el = host.current, badge = card.current, path = rope.current, s = rig.current
  let frame, last = 0, active = true, visible = true
  if (reduced) s.y = 0
  const observer = new IntersectionObserver(([entry]) => {visible=entry.isIntersecting}); observer.observe(el)
  const tick = now => {
   frame = requestAnimationFrame(tick)
   const dt = Math.min((now-(last || now))/1000,.025); last = now
   if (!visible || document.hidden) return
   if (!reduced) {
    const stiffness=s.dragging?170:32, damping=s.dragging?20:7
    s.vx += ((s.dragging?s.tx:0)-s.x)*stiffness*dt-s.vx*damping*dt
    s.vy += ((s.dragging?s.ty:0)-s.y)*stiffness*dt-s.vy*damping*dt
    s.x += s.vx*dt; s.y += s.vy*dt
   } else { s.x=s.dragging?s.tx:0;s.y=s.dragging?s.ty:0 }
   s.flip += (s.target-s.flip)*Math.min(1,dt*(reduced?40:9))
   s.angle += ((s.x*.06+s.vx*.025)-s.angle)*Math.min(1,dt*6)
   badge.style.transform=`translate3d(${s.x}px,${s.y}px,0) rotate(${s.angle}deg) rotateY(${s.flip+s.tilt}deg)`
   const rect=el.getBoundingClientRect(), x=rect.width/2+s.x, y=badge.parentElement.offsetTop+s.y
   path.setAttribute('d',`M ${rect.width/2} -25 Q ${rect.width/2-s.x*.25} ${Math.max(0,y*.5)} ${x} ${y}`)
  }; frame=requestAnimationFrame(tick)
  const timer = setInterval(()=>{if(active && visible && !document.hidden && !s.dragging && !reduced) {s.target+=180;setBack(Math.round(s.target/180)%2===1)}},5600)
  const scroll = () => { if(visible && !s.dragging && !reduced)s.vx+=Math.min(15,Math.abs(window.scrollY-s.previousScroll || 0));s.previousScroll=window.scrollY }
  window.addEventListener('scroll',scroll,{passive:true})
  return()=>{active=false;cancelAnimationFrame(frame);clearInterval(timer);observer.disconnect();window.removeEventListener('scroll',scroll)}
 },[ready,reduced])
 const down=e=>{if(e.button>0)return;const s=rig.current;s.dragging=true;s.moved=false;s.startX=e.clientX;s.startY=e.clientY;s.originX=s.x;s.originY=s.y;s.tx=s.x;s.ty=s.y;e.currentTarget.setPointerCapture(e.pointerId)}
 const move=e=>{const s=rig.current;if(s.dragging){s.moved ||= Math.hypot(e.clientX-s.startX,e.clientY-s.startY)>6;s.tx=Math.max(-150,Math.min(150,s.originX+e.clientX-s.startX));s.ty=Math.max(-130,Math.min(100,s.originY+e.clientY-s.startY))}else if(!reduced && e.pointerType==='mouse'){const r=e.currentTarget.getBoundingClientRect();s.tilt=(e.clientX-r.left-r.width/2)/r.width*16}}
 return <div className="im-badge-stage" ref={host}><svg className="im-lanyard" aria-hidden="true"><path ref={rope}/></svg><div className="im-badge-anchor"><div className="im-badge" ref={card} onPointerDown={down} onPointerMove={move} onPointerUp={()=>{const s=rig.current;s.dragging=false;if(!s.moved)flip()}} onPointerCancel={()=>{rig.current.dragging=false}} onPointerLeave={()=>{rig.current.tilt=0}}><div className="im-badge-clip"/><div className="im-badge-face im-badge-front"><div className="im-pass-label">PORTFOLIO PASS <span>YE—001</span></div><img className="im-pass-photo" src={profile.avatar} alt={profile.name} draggable="false"/><div className="im-pass-name">{profile.name}</div><p className="im-pass-role">SOFTWARE ENGINEER<br/>+ FULL-STACK DEVELOPER</p><div className="im-pass-status"><span><i/> AVAILABLE<br/><small>BASED IN MOROCCO</small></span><em>{profile.firstName}</em></div><div className="im-pass-bottom"><span className="im-barcode"/><span>BUILD. SHIP. REPEAT. ↗</span></div></div><div className="im-badge-face im-badge-back"><div className="im-pass-label">MY EXPERTISE <ArrowUpRight size={22}/></div>{[{icon:Code2,title:'FULL-STACK ENGINEERING',text:'React, Next.js, Node.js'},{icon:Layers,title:'SYSTEM ARCHITECTURE',text:'APIs, databases, scalable platforms'},{icon:Cpu,title:'CREATIVE TECHNOLOGY',text:'Motion, interactions, AI integration'},{icon:Globe,title:'WEB EXPERIENCES',text:'Performance, accessibility, detail'}].map(({icon:Icon,title,text})=><div key={title} className="im-expertise-row"><Icon size={20}/><div><b>{title}</b><small>{text}</small></div></div>)}<em>Thoughtfully designed.<br/>Carefully engineered.</em><div className="im-pass-bottom"><small>{profile.socials.email.replace('mailto:','')}</small><span className="im-barcode"/></div></div></div></div><button className="im-flip-button" onClick={flip} aria-label={`Flip portfolio pass to ${back?'front':'expertise'}`}>↻ Flip the pass <span>or drag it around</span></button></div>
}
