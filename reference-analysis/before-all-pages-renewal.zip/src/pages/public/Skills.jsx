import { useEffect, useRef, useState } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { dataService } from '../../lib/dataService'
import SEO from '../../components/ui/SEO'

gsap.registerPlugin(ScrollTrigger)

const DEFAULT_CATEGORIES = [
    {
        category: "Frontend", items: [
            { name: "React / Next.js", level: 90 },
            { name: "TypeScript", level: 85 },
            { name: "Tailwind CSS", level: 95 },
            { name: "GSAP", level: 80 }
        ]
    },
    {
        category: "Backend", items: [
            { name: "Node.js", level: 75 },
            { name: "Supabase / PostgreSQL", level: 70 },
            { name: "Python", level: 60 },
            { name: "GraphQL", level: 65 }
        ]
    },
    {
        category: "Tools & Design", items: [
            { name: "Git / GitHub", level: 90 },
            { name: "Figma", level: 85 },
            { name: "Docker", level: 50 },
            { name: "Adobe Creative Suite", level: 70 }
        ]
    }
]

export default function Skills() {
    const containerRef = useRef(null)
    const [categories, setCategories] = useState(DEFAULT_CATEGORIES)
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        dataService.getSkills().then(rawSkills => {
            if (rawSkills && rawSkills.length > 0 && rawSkills[0].category) {
                // Group by category
                const groups = {}
                rawSkills.forEach(s => {
                    const cat = s.category || 'Other'
                    if (!groups[cat]) groups[cat] = []
                    groups[cat].push({ name: s.name, level: s.level || 80 })
                })
                const groupedArray = Object.keys(groups).map(k => ({
                    category: k,
                    items: groups[k]
                }))
                setCategories(groupedArray)
            }
            setLoading(false)
        }).catch(() => setLoading(false))
    }, [])

    useEffect(() => {
        if (loading) return
        const ctx = gsap.context(() => {
            // Animate categories
            gsap.from('.skill-category', {
                y: 40,
                opacity: 0,
                duration: 0.7,
                stagger: 0.15,
                scrollTrigger: {
                    trigger: containerRef.current,
                    start: 'top 80%'
                }
            })

            // Animate progress bars
            gsap.utils.toArray('.progress-bar').forEach(bar => {
                gsap.to(bar, {
                    width: bar.dataset.width + '%',
                    duration: 1.2,
                    ease: 'power2.out',
                    scrollTrigger: {
                        trigger: bar,
                        start: 'top 90%'
                    }
                })
            })
        }, containerRef)

        return () => ctx.revert()
    }, [loading, categories])

    return (
        <>
            <SEO
                title="Skills & Technologies"
                description="Technical skills, technologies, and tools including React, TypeScript, Node.js, Supabase, Tailwind CSS, Docker, and system architecture."
                url="/skills"
            />
            <div ref={containerRef} className="container mx-auto px-4 pt-32 pb-32">
                <div className="text-center max-w-2xl mx-auto mb-16">
                    <p className="text-primary font-mono text-sm uppercase tracking-widest mb-3">EXPERTISE /</p>
                    <h1 className="text-4xl md:text-6xl font-heading font-bold text-white mb-4">
                        Technical Arsenal
                    </h1>
                    <p className="text-gray-400 text-sm md:text-base">
                        Core programming languages, frameworks, databases, and development workflows.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {categories.map((category, idx) => (
                        <div key={idx} className="skill-category bg-[#0d0d0f] p-8 rounded-2xl border border-white/10 backdrop-blur-sm hover:border-primary/40 transition-colors">
                            <h3 className="text-xl font-heading font-bold mb-6 text-white border-b border-white/10 pb-3 flex items-center justify-between">
                                <span>{category.category}</span>
                                <span className="text-xs font-mono text-gray-500 font-normal">{category.items.length} skills</span>
                            </h3>
                            <div className="space-y-5">
                                {category.items.map(skill => (
                                    <div key={skill.name}>
                                        <div className="flex justify-between mb-2 text-sm">
                                            <span className="text-gray-300 font-medium">{skill.name}</span>
                                            <span className="text-primary font-mono text-xs">{skill.level}%</span>
                                        </div>
                                        <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                                            <div
                                                className="progress-bar h-full bg-gradient-to-r from-primary to-secondary rounded-full w-0"
                                                data-width={skill.level}
                                            />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </>
    )
}
