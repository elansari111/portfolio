import { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { Lock, Mail, Eye, EyeOff, ArrowLeft, AlertCircle, ShieldCheck } from 'lucide-react'
import { useAuth } from '../../context/AuthContext'

export default function Login() {
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [error, setError] = useState('')
    const [submitting, setSubmitting] = useState(false)
    const [showPw, setShowPw] = useState(false)
    const { signIn, user, isConfigured } = useAuth()
    const navigate = useNavigate()

    useEffect(() => {
        if (user) {
            navigate('/admin', { replace: true })
        }
    }, [user, navigate])

    const handleSubmit = async (e) => {
        e.preventDefault()
        setError('')
        setSubmitting(true)

        if (!isConfigured) {
            setError('Supabase is not configured yet. Please check your .env variables.')
            setSubmitting(false)
            return
        }

        try {
            const { error: authError } = await signIn({ email: email.trim(), password })
            if (authError) {
                throw authError
            }
            navigate('/admin', { replace: true })
        } catch (err) {
            console.error('Login error:', err)
            setError(err.message || 'Authentication failed. Please verify your credentials.')
        } finally {
            setSubmitting(false)
        }
    }

    return (
        <div className="min-h-screen flex items-center justify-center bg-black px-4 relative overflow-hidden">
            {/* Ambient background glow */}
            <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-primary/20 rounded-full blur-[120px] pointer-events-none" />

            <div className="w-full max-w-md relative z-10">
                {/* Back to site link */}
                <div className="mb-6">
                    <Link
                        to="/"
                        className="inline-flex items-center gap-2 text-gray-500 hover:text-white text-sm transition-colors"
                    >
                        <ArrowLeft size={16} />
                        Back to Portfolio
                    </Link>
                </div>

                {/* Header */}
                <div className="text-center mb-8">
                    <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 text-primary mb-4 shadow-lg shadow-primary/10">
                        <ShieldCheck size={28} />
                    </div>
                    <h1 className="text-2xl font-heading font-bold text-white">Admin Authentication</h1>
                    <p className="text-gray-400 text-sm mt-1">Sign in with your Supabase account to manage the portfolio</p>
                </div>

                <form onSubmit={handleSubmit} className="bg-[#0d0d0f] border border-white/10 rounded-2xl p-8 space-y-5 shadow-2xl backdrop-blur-xl">
                    {!isConfigured && (
                        <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-start gap-2.5">
                            <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
                            <span>
                                Supabase environment variables are missing in <code className="text-amber-200 font-mono">.env</code>. Make sure <code className="text-amber-200 font-mono">VITE_SUPABASE_URL</code> and <code className="text-amber-200 font-mono">VITE_SUPABASE_ANON_KEY</code> are set.
                            </span>
                        </div>
                    )}

                    {error && (
                        <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs flex items-start gap-2.5">
                            <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
                            <span>{error}</span>
                        </div>
                    )}

                    {/* Email Field */}
                    <div className="space-y-1.5">
                        <label htmlFor="admin-email" className="block text-xs text-gray-400 uppercase tracking-wider font-medium">
                            Admin Email
                        </label>
                        <div className="relative">
                            <input
                                id="admin-email"
                                type="email"
                                value={email}
                                onChange={e => { setEmail(e.target.value); setError('') }}
                                className="w-full bg-black/60 border border-white/10 rounded-xl px-4 py-3 pl-10 text-white text-sm outline-none focus:border-primary transition-colors placeholder-gray-600"
                                placeholder="admin@example.com"
                                autoComplete="email"
                                required
                            />
                            <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500" />
                        </div>
                    </div>

                    {/* Password Field */}
                    <div className="space-y-1.5">
                        <label htmlFor="admin-password" className="block text-xs text-gray-400 uppercase tracking-wider font-medium">
                            Password
                        </label>
                        <div className="relative">
                            <input
                                id="admin-password"
                                type={showPw ? 'text' : 'password'}
                                value={password}
                                onChange={e => { setPassword(e.target.value); setError('') }}
                                className="w-full bg-black/60 border border-white/10 rounded-xl px-4 py-3 pl-10 pr-11 text-white text-sm outline-none focus:border-primary transition-colors placeholder-gray-600"
                                placeholder="••••••••••••"
                                autoComplete="current-password"
                                required
                            />
                            <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500" />
                            <button
                                type="button"
                                onClick={() => setShowPw(!showPw)}
                                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition-colors"
                                aria-label={showPw ? 'Hide password' : 'Show password'}
                            >
                                {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                            </button>
                        </div>
                    </div>

                    <button
                        type="submit"
                        disabled={submitting}
                        className="w-full bg-primary hover:bg-primary/80 disabled:opacity-50 text-white py-3 rounded-full font-semibold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-primary/20"
                    >
                        {submitting ? (
                            <>
                                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                                <span>Authenticating...</span>
                            </>
                        ) : (
                            <>
                                <Lock size={16} />
                                <span>Sign In with Supabase</span>
                            </>
                        )}
                    </button>

                    <div className="pt-2 text-center text-xs text-gray-500">
                        Protected with Supabase Auth & Row Level Security (RLS)
                    </div>
                </form>
            </div>
        </div>
    )
}
