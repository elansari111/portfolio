export const palettes = [
    { name: 'Plum', bg: '#310744', fg: '#faeeff', accent: '#df36ed', lightAccent: '#9b1eaa' },
    { name: 'Forest', bg: '#073424', fg: '#ebf9e5', accent: '#65dd94', lightAccent: '#167447' },
    { name: 'Midnight', bg: '#101c48', fg: '#edf1ff', accent: '#86a6ff', lightAccent: '#345baf' },
    { name: 'Ember', bg: '#46170e', fg: '#fff1e4', accent: '#ff8355', lightAccent: '#b33b17' },
]
export function readPalette() {
    try {
        const value = Number(sessionStorage.getItem('portfolio-palette'))
        return Number.isInteger(value) && value >= 0 && value < palettes.length ? value : 0
    } catch { return 0 }
}
export function appearanceTokens(index, isDark) {
    const palette = palettes[index] || palettes[0]
    return {
        '--im-bg': isDark ? palette.bg : palette.fg,
        '--im-fg': isDark ? palette.fg : palette.bg,
        '--im-accent': isDark ? palette.accent : palette.lightAccent,
        '--im-ink': palette.bg,
        '--im-footer-ink': isDark ? palette.bg : palette.fg,
    }
}
